#!/bin/bash
# One-shot cron (orion-r3-prod): Phase 3 R3 prod release block under Mike's pre-approval (2026-11-21 "good to go,
# pre-approved for prod at your schedule"). Gates: stage's s0-s4 all passed (marker), stage's soak nightly
# (2026-11-22T02:45Z on the tag: done, no failed source, no ORION WATCH / ORION ALERT line in stage logs since the
# switch), time window (prod 02:45-20:45Z, outside 05:00-06:30 PT, end of s3 before Sunday's 10:30Z staging_refresh).
# Then prod s0 -> s1 -> s2 -> s3 -> s4, stopping at the first non-zero exit. Full logs in $L; stdout = condensed report.
set -u
TAG=orion-2026.11.21.1
T=/home/hermes/git/orion/.worktrees/tag-2026.11.21.1
L=/home/hermes/.hermes/profiles/raymond/workspace/orion/phase3-proof/r3/prod-run
mkdir -p $L
ST="ssh -i /home/hermes/.ssh/orion-stage_ed25519 -o IdentitiesOnly=yes orion-stage@192.168.0.12"
say() { echo "$*"; echo "$*" >> $L/chain.log; }
halt() { say "STOP (prod chain): $*"; say "Prod NOT advanced past this point. Logs: $L"; exit 0; }
say "== Orion R3 prod chain $(date -u +%FT%TZ)"
now=$(date -u +%s)
[ $now -ge $(date -u -d 2026-11-22T03:00:00Z +%s) ] || halt "too early"
[ $now -lt $(date -u -d 2026-11-22T07:30:00Z +%s) ] || halt "too late to finish s3 before the 10:30Z staging_refresh with margin"
hm=$(TZ=America/Los_Angeles date +%H%M); [ "$hm" -ge 0500 ] && [ "$hm" -lt 0630 ] && halt "inside 05:00-06:30 PT"
[ -f /home/hermes/r3-stage/STAGE-PASSED ] || halt "stage s0-s4 not all passed (no /home/hermes/r3-stage/STAGE-PASSED)"
[ -d /home/hermes/r3-prod ] && halt "/home/hermes/r3-prod exists (a previous prod run): needs a look"
# soak gate
$ST status --json > $L/stage-status.json 2>&1 || halt "stage status exit $?"
python3 - $L/stage-status.json $TAG <<'E' >> $L/chain.log 2>&1 || halt "stage soak gate failed: $(tail -1 $L/chain.log)"
import json, sys
d = json.load(open(sys.argv[1])); n = d.get('last_nightly') or {}
ok = n.get('tag') == sys.argv[2] and n.get('nightly_slot') == '2026-11-22T02:45:00.000Z' and n.get('status') == 'done' and n.get('failed_sources') == []
print(f"soak nightly: {json.dumps(n)}")
sys.exit(0 if ok else 1)
E
say "soak nightly ok: $(tail -1 $L/chain.log)"
$ST logs 2000 > $L/stage-logs.txt 2>&1 || halt "stage logs exit $?"
python3 - $L/stage-logs.txt > $L/stage-watch.txt <<'E'
import sys
lines = open(sys.argv[1]).read().splitlines()
i = max([k for k, l in enumerate(lines) if 'daemon started' in l and 'orion-2026.11.21.1' in l] or [0])
for l in lines[i:]:
    if 'ORION WATCH' in l or 'ORION ALERT' in l: print(l)
E
[ -s $L/stage-watch.txt ] && halt "stage WATCH/ALERT lines since the switch: $(head -3 $L/stage-watch.txt | tr '\n' ' ')"
say "soak logs ok (no ORION WATCH / ORION ALERT on stage since the switch)"
run() { local n=$1; shift; say "== prod $n start $(date -u +%T)"; "$@" > $L/$n.log 2>&1; local rc=$?
  grep -E '^(STOP|== |.* ok( |$)|.*: market_data|kept|market_data total|levels|gate|s[0-4] done)' $L/$n.log | grep -v '^== install' | tail -40 | tee -a $L/chain.log
  say "== prod $n exit $rc $(date -u +%T)"; [ $rc -eq 0 ] || halt "prod $n exit $rc (full log $L/$n.log)"; }
run s0 $T/tools/phase3-proof/r3-s0.sh prod
run s1 $T/tools/phase3-proof/r3-s1.sh prod $TAG --tools $T
run s2 $T/tools/phase3-proof/r3-s2.sh prod
run s3 $T/tools/phase3-proof/r3-s3.sh prod
run s4 $T/tools/phase3-proof/r3-s4.sh prod --tools $T
say "PROD R3 COMPLETE: s0-s4 all ok, gate passed $(date -u +%FT%TZ)"
